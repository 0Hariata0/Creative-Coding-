function setup() {
	createCanvas(800, 800);
	background(255);
}

function draw() { 
  // Head
  fill(181, 143, 105);
	ellipse(height/2, width/2, 450, 350);
  
	//Eyes
  fill(148, 107, 81);
	ellipse(325, 350, 100, 150);
	ellipse(465, 350, 100, 150);
	fill(0, 0, 0);
	ellipse(325, 350, 80, 120);
	ellipse(465, 350, 80, 120);
	fill(255, 255, 255);
	ellipse(315, 320, 20, 20);
	ellipse(475, 320, 20, 20);
	ellipse(335, 350, 30, 30);
	ellipse(455, 350, 30, 30);
	
  // Ears
  fill(100, 50, 10);
  ellipse(230, 435, 144, 335);
  ellipse(560, 435, 144, 335);
	
	//Nose
	fill(181, 143, 105);
	ellipse(393, 500, 300, 200);
	fill(100, 50, 10);
  ellipse(393, 445, 170, 90);
	fill(0, 0, 0);
	ellipse(352, 430, 55, 45);
	ellipse(435, 430, 55, 45);
	


  
	
	

	
	
}