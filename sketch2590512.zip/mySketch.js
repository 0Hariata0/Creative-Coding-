//step 1: declare the variable (saying to computer that it is a thing)
let x;
let y;
let xoff = 0.2;
let yoff = 0.8;


function setup () {
	createCanvas(850, 850);
	background(180);
	
//change your frame rate if getting lag
	frameRate(30);
//step 2: init the variable (giving it a starting point)

	
}

function draw() {
	
	x = map(noise(xoff), 0, 1, 50, width-50);
	y = map(noise(yoff), 0, 1 , 50, height-50);
	
	fill( random(40, 255), random(255), random(255) );
	ellipse(x, y, 100, 100);
	
	xoff += 0.01;
	yoff += 0.01;
}

function mousePressed() {
	background(180);

}

function keyPressed(){
	if(key == 'g'){
		saveGif('Perlin Noise Rainbow Circle', 8);
	}
	
}
//230, 255, 24