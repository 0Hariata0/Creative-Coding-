function setup() {
	createCanvas(800, 800);
	background(255);
}

function draw() {
	
	r = random(255);
	g = random (255);
	b = random (255);
	
	noFill();
	strokeWeight(random(1, 10));
	stroke(r, g, b);
	beginShape();
	for(y = 0; y < height; y++){
		let x = random(width);
		stroke(r, g, b);
		vertex(x, y);
		
		
	}
	endShape();
}